fetch("data.json")
  .then(response => response.json())
  .then(data => {
    const table = document.querySelector("#table tbody");
    const search = document.getElementById("search");

    function render(filtered) {
      table.innerHTML = "";
      filtered.forEach(vuz => {
        table.innerHTML += `
          <tr>
            <td>${vuz.name}</td>
            <td>${vuz.city}</td>
            <td>${vuz.type}</td>
            <td>${vuz.rating}</td>
            <td><a href="${vuz.website}" target="_blank">Перейти</a></td>
          </tr>`;
      });
    }

    render(data);

    search.addEventListener("input", () => {
      const text = search.value.toLowerCase();
      const filtered = data.filter(v =>
        v.name.toLowerCase().includes(text)
      );
      render(filtered);
    });
  });
